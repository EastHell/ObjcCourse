//
//  AppDelegate.h
//  UIViewDrawingsTask
//
//  Created by Aleksandr on 10/08/2019.
//  Copyright © 2019 Aleksandr Shushkov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

