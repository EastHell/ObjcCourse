//
//  DrawingView.h
//  UIViewDrawingsTask
//
//  Created by Aleksandr on 12/08/2019.
//  Copyright © 2019 Aleksandr Shushkov. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DrawingView : UIView

@end

NS_ASSUME_NONNULL_END
