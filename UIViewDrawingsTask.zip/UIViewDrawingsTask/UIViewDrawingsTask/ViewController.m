//
//  ViewController.m
//  UIViewDrawingsTask
//
//  Created by Antipharmakon Aeolis  on 10/08/2019.
//  Copyright © 2019 Aleksandr Shushkov. All rights reserved.
//

#import "ViewController.h"
#import "DrawingView.h"
#import "PaintingView.h"

@interface ViewController ()

@property (assign, nonatomic) CGContextRef context;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.paintingView addGestureRecognizer:panGesture];
}

#pragma mark - Orientation

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [self.drawingView setNeedsDisplay];
    [self.paintingView setNeedsDisplay];
}

- (void)handlePan:(UIPanGestureRecognizer *)panGesture {
    if (panGesture.state == UIGestureRecognizerStateBegan) {
        [self.paintingView startPoint:[panGesture locationInView:self.paintingView]];
    }
    [self.paintingView drawToPoint:[panGesture locationInView:self.paintingView]];
}

@end
