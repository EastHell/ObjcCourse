//
//  PaintingView.m
//  UIViewDrawingsTask
//
//  Created by Aleksandr on 17/08/2019.
//  Copyright © 2019 Aleksandr Shushkov. All rights reserved.
//

#import "PaintingView.h"

@implementation PaintingView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code    
}

- (void)startPoint:(CGPoint)point {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(context, point.x, point.y);
}

- (void)drawToPoint:(CGPoint)point {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [UIColor redColor].CGColor);
    CGContextAddLineToPoint(context, point.x, point.y);
    CGContextFillPath(context);
}

@end
